Please use the password "admin" to access the Modify Employee/User page.

